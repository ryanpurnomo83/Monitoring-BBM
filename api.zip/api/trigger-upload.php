<?php

require 'vendor/autoload.php';
use Google\Cloud\Firestore\FirestoreClient;
use Kreait\Firebase\Factory;
            
$serviceAPath = '/home/qibiujnz/public_html/api/monitoring-bbm-my-id-4231a6208e71.json';
$factory = (new Factory)->withServiceAccount($serviceAPath);
$firestore = $factory->createFirestore(); 

$servername = "monitoring-bbm.my.id";
$username = "qibiujnz_bbm-tbb-monitoring";
$password = "VOo;ql(0oLMz";
$dbname = "qibiujnz_bbm-tbb-monitoring";

// Koneksi ke database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Koneksi ke database gagal: " . $conn->connect_error);
}

// Ambil data user
$sql = "SELECT * FROM users"; 
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    
    while ($row = $result->fetch_assoc()){
    //$row = $result->fetch_assoc();
    $latestUserId = $row['id'];
    $latestUserCompanyName = $row['companyname'];

    $newFileName = 'upload_' . $latestUserCompanyName . '.php';
    $directory = '/home/qibiujnz/public_html/api/';
    $filePath = $directory . $newFileName;

    $fileContent = "<?php
        require 'vendor/autoload.php';
        include 'connection-upload.php';
        use Google\Cloud\Firestore\FirestoreClient;
        use Kreait\Firebase\Factory;
        
        \$servername = 'monitoring-bbm.my.id';
        \$username = 'qibiujnz_bbm-tbb-monitoring';
        \$password = 'VOo;ql(0oLMz';
        \$dbname = 'qibiujnz_bbm-tbb-monitoring';
        
        \$conn = new mysqli(\$servername, \$username, \$password, \$dbname);
        
        if (\$conn->connect_error) {
            die('Connection failed: ' . \$conn->connect_error);
        }

        \$serviceAPath = '/home/qibiujnz/public_html/api/monitoring-bbm-my-id-4231a6208e71.json';
        \$factory = (new Factory)->withServiceAccount(\$serviceAPath);
        \$firestore = \$factory->createFirestore();
        
        \$collectionName = '$latestUserCompanyName';
        \$data = [];
        \$tableId = sendDataUser(\$collectionName, \$company_name, \$nik);
        \$documentId = 'K01';
        \$weeksNumber = 1;
        \$subcollectionName = 'Minggu ' . \$weeksNumber;
        \$count = 0; 

        \$NIK = \$_POST['NIK'] ?? null;
        \$mapp = \$_POST['isi'] ?? null;
        \$rssi = \$_POST['rssi'] ?? null; 
        
        foreach (\$tableId as \$index => \$tblid) {
                
                \$tablei = \$tableId[\$index % 2];
                echo '<br> Mengisi data ke tabel dengan ID: ' . \$tablei;
                
                //sql part
                \$sql = 'SELECT * FROM monitoring WHERE nik = ?';
                \$stmt = \$conn->prepare(\$sql);
                \$stmt->bind_param('s', \$tablei); 
                \$stmt->execute();
                \$result = \$stmt->get_result();
                
                if (\$result->num_rows > 0) {
                    while (\$row = \$result->fetch_assoc()) {
                        \$data = [
                            'nik' => \$row['nik'],
                            'level' => \$row['level'],
                            'jarak' => \$row['jarak'],
                            'timestamp' => new \Google\Cloud\Core\Timestamp(new \DateTime())
                        ];
                        
                        \$nikck = \$data['nik'];
                        
                        if(\$nikck == \$tablei){
                           \$collection = \$firestore->database()->collection(\$collectionName);
                           \$documentRef = \$collection->document(\$tablei);
                            
                           while (true) {
                                \$subcollectionRef = \$documentRef->collection(\$subcollectionName);
                                \$documents = \$subcollectionRef->documents();
                            
                                if (\$documents->size() === 0) {
                                    break;
                                }
                        
                                \$firstDocument = \$documents->rows()[0];
                                \$creationTimestamp = \$firstDocument->data()['timestamp'];
                                \$creationDate = \$creationTimestamp->get()->format('Y-m-d H:i:s');
                                    
                                \$currentDate = new DateTime();
                                \$interval = \$currentDate->diff(new DateTime(\$creationDate));
                                
                                if (\$interval->days >= 7) {
                                    \$weeksNumber++;
                                    \$subcollectionName = 'Minggu ' . \$weeksNumber;
                                } else {
                                    break;
                                }
                            }
                            
                            \$collectionRef = \$documentRef->collection(\$subcollectionName);
                            \$documents = \$collectionRef->documents();
                            \$count = \$documents->size();
                        
                            if (\$count === 0) {
                                \$dataId = '1';
                            } else {
                                \$dataId = \$count+1;
                            }
                            \$id = strval(\$dataId);
            
                
                            try {
                                \$subDocumentRef = \$documentRef->collection(\$subcollectionName)->document(\$id);
                                \$subDocumentRef->set(\$data);
                                echo 'Data berhasil diupload ke Firestore';
                            } catch(Exception \$e) {
                                echo 'Terjadi kesalahan: ' . \$e->getMessage();
                            }
                        }
                    }
                } else {
                    echo 'Tidak ada data untuk NIK: \$tablei';
                }
                //sql close
        }
        \$conn->close();
    ?>";

    if (file_exists($filePath)) {
        echo "File $newFileName sudah ada!";
    } else {
        if (file_put_contents($filePath, $fileContent) !== false) {
            echo "File $newFileName berhasil dibuat di $directory karena ada user baru dengan ID: " . $latestUserId;
        } else {
            echo "Gagal membuat file $newFileName";
        }
    }
  }
} else {
    echo "Tidak ada user baru yang ditemukan di tabel user.";
}

$conn->close();

?>
