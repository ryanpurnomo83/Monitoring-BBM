<?php

$servername = "monitoring-bbm.my.id";
$username = "qibiujnz_bbm-tbb-monitoring";
$password = "VOo;ql(0oLMz";
$dbname = "qibiujnz_bbm-tbb-monitoring";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM users"; 
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $latestUserId = $row['id'];
        $latestUserCompanyName = $row['companyname'];

        // Memastikan nama perusahaan hanya terdiri dari karakter yang valid untuk nama tabel
        $safeCompanyName = preg_replace('/[^a-zA-Z0-9_]/', '_', $latestUserCompanyName);
        $tableName = 'upload_' . $safeCompanyName;

        // Membuat query untuk membuat tabel
        $createTableSQL = "CREATE TABLE IF NOT EXISTS `$tableName` (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nik VARCHAR(255) NOT NULL,
            companyname VARCHAR(255) NOT NULL,
            level VARCHAR(255) NOT NULL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";

        // Eksekusi query untuk membuat tabel
        if ($conn->query($createTableSQL) === TRUE) {
            echo "Tabel '$tableName' berhasil dibuat.<br>";
        } else {
            echo "Error: " . $conn->error . "<br>";
        }
    }
} else {
    echo "Tidak ada data pengguna ditemukan.<br>";
}

$conn->close();
?>
