<?php
        $servername = 'monitoring-bbm.my.id';
        $username = 'qibiujnz_bbm-tbb-monitoring';
        $password = 'VOo;ql(0oLMz';
        $dbname = 'qibiujnz_bbm-tbb-monitoring';
        $collectionName = 'Perusahaan Tambang A';
        
        $conn = new mysqli($servername, $username, $password, $dbname);
        
        if ($conn->connect_error) {
            die('Connection failed: ' . $conn->connect_error);
        }
        
        $selectSql = "SELECT * FROM monitoring WHERE companyname = '$collectionName'";
        $result = $conn->query($selectSql);
        $collectionName= str_replace(" ", "_", $collectionName);
        
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                
                $insertSql = "INSERT INTO upload_$collectionName (nik, companyname, level, timestamp)
                               VALUES ('{$row['nik']}', '{$row['companyname']}', '{$row['level']}', '{$row['timestamp']}')";
                if (!$conn->query($insertSql)) {
                    echo 'Gagal memasukkan data: ' . $conn->error;
                }
            }
            echo 'Data berhasil dimasukkan ke tabel upload_$collectionName.';
        } else {
            echo 'Tidak ada data di tabel monitoring untuk companyname: $collectionName.';
        }  
        
        $conn->close();
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <script type="text/javascript">
        setInterval(function() {
            location.reload();
        }, 1000); 
    </script>
</body>
</html>