<?php

$servername = "monitoring-bbm.my.id";
$username = "qibiujnz_bbm-tbb-monitoring";
$password = "VOo;ql(0oLMz";
$dbname = "qibiujnz_bbm-tbb-monitoring";

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$folderPath = "/home/qibiujnz/public_html/api/";
$pattern = $folderPath . "upload_*.php";
$files = glob($pattern);

foreach ($files as $file) {
    $filename = $conn->real_escape_string(basename($file));
    
    $checkQuery = "SELECT COUNT(*) AS count FROM process WHERE filename = '$filename'";
    $result = $conn->query($checkQuery);

    if ($result) {
        $row = $result->fetch_assoc();
        if ($row['count'] == 0) {
            // Masukkan ke database
            $insertQuery = "INSERT INTO process (filename, status) VALUES ('$filename', 'STOP')";
            if ($conn->query($insertQuery) === TRUE) {
                echo "File $filename berhasil dimasukkan ke database.<br>";
            } else {
                echo "Error: " . $conn->error . "<br>";
            }
        } else {
            echo "File $filename sudah ada di database.<br>";
        }
    } else {
        echo "Error: " . $conn->error . "<br>";
    }
}
$conn->close();
?>

