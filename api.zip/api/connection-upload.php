<?php
include 'user-verification.php';

$servername = "monitoring-bbm.my.id";
$username = "qibiujnz_bbm-tbb-monitoring";
$password = "VOo;ql(0oLMz";
$dbname = "qibiujnz_bbm-tbb-monitoring";
$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = callUserToVerify($conn);
$company_name = [];
$documentId = [];
$nik = [];

if(is_array($result)){
    foreach ($result as $r) {
         $company_name[] = $r['companyname'] . "\n";
         $nik[] = $r['nik'] . "\n";
    }
}

function sendDataUser($collectionName, $company_name, $nik){
    foreach($company_name as $key => $cmpnynm){
        if($collectionName === trim($cmpnynm)){
            $documentId[] = trim($nik[$key]);
        }
    }
    return $documentId;
}

$conn->close();
?>
