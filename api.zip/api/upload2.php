<?php

$servername = "monitoring-bbm.my.id";
$username = "qibiujnz_bbm-tbb-monitoring";
$password = "VOo;ql(0oLMz";
$dbname = "qibiujnz_bbm-tbb-monitoring";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$NIK = $_POST['NIK'] ?? null;
$companyname = $_POST['companyname'] ?? null;
$mapp = $_POST['BBM'] ?? null;

$faktor_per_liter = 0.9;

if ($NIK !== null && $companyname !== null && $mapp !== null) {
    $mapp = $mapp -288 ;
    $liter = $mapp / $faktor_per_liter;

    $stmt = $conn->prepare("INSERT INTO monitoring (nik, companyname, level) VALUES (?, ?, ?)");
    $stmt->bind_param("ssd", $NIK, $companyname, $liter); 

    if ($stmt->execute()) {
        echo "Data inserted successfully";
    } else {
        echo "Error inserting data: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "No data received";
}

$conn->close();

?>