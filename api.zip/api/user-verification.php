<?php

$servername = "monitoring-bbm.my.id";
$username = "qibiujnz_bbm-tbb-monitoring";
$password = "VOo;ql(0oLMz";
$dbname = "qibiujnz_bbm-tbb-monitoring";
$conn = new mysqli($servername, $username, $password, $dbname);
$status = false;


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function insertUserToVerify($conn, $userid, $companyname, $statususer, $NIK) {
    if ($userid !== null && $companyname !== null && $statususer !== null && $NIK !== null) {
            $insertStmt = $conn->prepare("INSERT INTO verifications (id, companyname, status, nik) VALUES (?, ?, ?, ?)");
            $insertStmt->bind_param("isis", $userid, $companyname, $statususer, $NIK);
            if ($insertStmt->execute()) {
                echo "Data inserted successfully";
            } else {
                echo "Error inserting data: " . $insertStmt->error;
            }
            $insertStmt->close();
    }else{
        echo "Invalid input: userid, companyname, and statususer are required.";
    }
}


function callUserToVerify($conn){
    $result = $conn->query("SELECT * FROM verifications WHERE status = 1");
            
    if($result){
        $rows = [];
        while($row = $result->fetch_assoc()){
            $rows[] = $row;
        }
                
        if (!empty($rows)) {
             return $rows;
        } else {
             return "No active data found for this user.";
        }
    }
}
   
$userid = $_POST['userid'] ?? null;
$companyname = $_POST['companyname'] ?? null;
$statususer = $_POST['statususer'] ?? null;
$NIK = $_POST['NIK'] ?? null;

echo $userid;
if ($userid && $companyname && $statususer && $NIK) {
    insertUserToVerify($conn, $userid, $companyname, $statususer, $NIK);
}else{
    $status = true;
    echo "missing userid and companyname";
}

$conn->close();
?>
