<?php

$servername = "monitoring-bbm.my.id";
$username = "qibiujnz_bbm-tbb-monitoring";
$password = "VOo;ql(0oLMz";
$dbname = "qibiujnz_bbm-tbb-monitoring";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "TRUNCATE TABLE monitoring";
if ($conn->query($sql) === TRUE) {
    echo "Semua data di tabel 'monitoring' telah dihapus.";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
