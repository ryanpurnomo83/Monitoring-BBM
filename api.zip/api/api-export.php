<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");

$csvFile = "sensor_results.csv";

if (!file_exists($csvFile)) {
    die(json_encode(["status" => "error", "message" => "Belum ada data"]));
}

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="sensor_results.csv"');
readfile($csvFile);
?>
