<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

$csvFile = "sensor_results.csv";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $json = file_get_contents("php://input");
    $data = json_decode($json, true);

    if (!isset($data["results"]) || !isset($data["summary"])) {
        die(json_encode(["status" => "error", "message" => "Format data tidak valid"]));
    }

    $results = $data["results"];
    $summary = $data["summary"];

    // Buat file CSV
    $csvContent = "Percobaan,Data Ke,Value,Latency (ms),Bandwidth (kbps)\n";

    foreach ($results as $percobaan => $values) {
        foreach ($values as $i => $entry) {
            $csvContent .= ($percobaan + 1) . "," . ($i + 1) . "," . $entry["value"] . "," . $entry["latency"] . "," . $entry["bandwidth"] . "\n";
        }
    }

    // Tambah ringkasan rata-rata
    $csvContent .= "\nPercobaan,Rata-rata Latency (ms),Rata-rata Bandwidth (kbps)\n";
    foreach ($summary as $percobaan => $entry) {
        $csvContent .= ($percobaan + 1) . "," . $entry["latency_avg"] . "," . $entry["bandwidth_avg"] . "\n";
    }

    file_put_contents($csvFile, $csvContent);

    echo json_encode(["status" => "success", "message" => "Data CSV berhasil disimpan", "download_url" => "https://monitoring-bbm.my.id/api/api-export.php"]);
}
?>
