<?php

$servername = "monitoring-bbm.my.id";
$username = "qibiujnz_bbm-tbb-monitoring";
$password = "VOo;ql(0oLMz";
$dbname = "qibiujnz_bbm-tbb-monitoring";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function stopProcess($filename) {
    $output = [];
    exec("pgrep -f $filename", $output);

    foreach ($output as $pid) {
        exec("kill -9 $pid");
    }
}

function startProcess($filename) {
    $output = [];
    exec("pgrep -f $filename", $output);

    if (empty($output)) {
        exec("php /home/qibiujnz/public_html/api/$filename > /dev/null 2>&1 &");
    }
}

$sql = "SELECT filename, status FROM process";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $filename = $row['filename'];
        $status = $row['status'];

        if ($status == 'START') {
            //echo $filename;
            startProcess($filename);
        } elseif ($status == 'STOP') {
            stopProcess($filename);
        }
    }
} else {
    echo "No records found in the process table.";
}

$conn->close();
?>
