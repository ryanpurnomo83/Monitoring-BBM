<?php
require 'vendor/autoload.php';
use Google\Cloud\Firestore\FirestoreClient;
use Kreait\Firebase\Factory;

$serviceAPath = '/home/qibiujnz/public_html/api/bbm-monitoring-d4d9c0dd382e.json';
$factory = (new Factory)->withServiceAccount($serviceAPath);
$firestore = $factory->createFirestore(); 

$collectionName = 'Perusahaan Tambang A';
$documentId = 'K01';
$subcollectionName = 'Minggu 1';
$id = 3; 
$subDocumentId = strval($id); 


$NIK = $_POST['NIK'] ?? null;
$mapp = $_POST['isi'] ?? null;
$rssi = $_POST['rssi'] ?? null; 

/*
$NIK = "K1";
$mapp = "67";
$rssi = "-164"; 
*/

if ($NIK !== null && $mapp !== null && $rssi !== null) {
    
    $data = [
        'nik' => $NIK,
        'level' => $mapp,
        'jarak' => $rssi,
        'timestamp' => new \Google\Cloud\Core\Timestamp(new \DateTime())  
    ];
    
    try {
        $documentRef = $firestore->database()->collection($collectionName)->document($documentId);
        $subDocumentRef = $documentRef->collection($subcollectionName)->document($subDocumentId);
        $subDocumentRef->set($data);
        
        echo "Data berhasil diupload ke Firestore";
    } catch(Exception $e) {
        echo "Terjadi kesalahan: " . $e->getMessage();
    }   
} else {
    echo "Data tidak lengkap.";makan
}
?>