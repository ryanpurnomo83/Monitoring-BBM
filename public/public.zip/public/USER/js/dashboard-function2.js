var dataContainer = null;
var dataFromServer = null;

dataContainer = document.getElementById('data-container4');
dataFromServer = JSON.parse(dataContainer.getAttribute('data-server-data4'));

console.log(dataFromServer);

const xValues = dataFromServer.map(item => {
  return item.timestamp;
});

const sortedXValues = Array.from(new Set(xValues)).sort((a, b) => new Date(a) - new Date(b));

//console.log(sortedXValues);

const groupedData = dataFromServer.reduce((acc, item) => {
  const nik = item.nik;
  if (!acc[nik]) {
    acc[nik] = [];
  }
  acc[nik].push(item);
  return acc;
}, {});

const colors = [
  { backgroundColor: "rgba(0,0,255,0.2)", borderColor: "rgba(0,0,255,0.6)" }, // Biru
  { backgroundColor: "rgba(255,165,0,0.2)", borderColor: "rgba(255,165,0,0.6)" }, // Oranye
  { backgroundColor: "rgba(0,128,0,0.2)", borderColor: "rgba(0,128,0,0.6)" }, // Hijau
  { backgroundColor: "rgba(255,0,0,0.2)", borderColor: "rgba(255,0,0,0.6)" } // Merah
];

const datasets = Object.keys(groupedData).map((nik, index) => {
  const color = colors[index % colors.length];
  return {
    label: `${nik}`,
    fill: false,
    lineTension: 0,
    backgroundColor: color.backgroundColor,
    borderColor: color.borderColor,
    data: groupedData[nik]
      .sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp))
      .map(item => ({
        x: new Date(item.timestamp),
        y: parseFloat(item.level)
      })),
  };
});

if (datasets.length === 0) {
  datasets.push({
    label: "No Data",
    fill: false,
    lineTension: 0,
    backgroundColor: "rgba(211,211,211,1.0)",
    borderColor: "rgba(211,211,211,0.6)",
    data: []
  });
}

new Chart("myChart", {
  type: "line",
  data: {
    datasets: datasets
  },
  options: {
    scales: {
      x: {
        type: 'time',
        time: {
          tooltipFormat: 'MMM D, YYYY HH:mm',
          displayFormats: {
            day: 'MMM D',
            hour: 'HH:mm'
          }
        },
        ticks: {
          autoSkip: true,
          maxTicksLimit: 10
        }
      },
      y: {
        beginAtZero: false,
        ticks: {
          callback: value => value.toFixed(2),
        },
        title: {
          display: true,
          text: 'Level'
        }
      }
    },
    plugins: {
      zoom: {
        zoom: {
          wheel: {
            enabled: true,
          },
          pinch: {
            enabled: true
          },
          mode: 'xy',
        }
      }
    }
  }
});

/*
const datasets2 = Object.keys(groupedData).map((nik, index) => {
  const color = colors[index % colors.length];
  return {
    label: `${nik}`,
    fill: true,
    lineTension: 0,
    backgroundColor: color.backgroundColor,
    borderColor: color.borderColor,
    data: groupedData[nik]
        .sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp)) 
        .map(item => ({
            x: new Date(item.timestamp), 
            y: item.level
        })),
  };
});

if (datasets2.length === 0) {
  datasets2.push({
    label: "No Data",
    fill: true,
    lineTension: 0,
    backgroundColor: "rgba(211,211,211,1.0)",
    borderColor: "rgba(211,211,211,0.6)",
    borderWidth: 1,
    data: Array(sortedXValues.length || 1).fill(0)
  });
  sortedXValues.push("No Data"); 
}

const initialData = {
    labels: sortedXValues,
    datasets: datasets2
};

[{
        label: 'Dummy Data',
        data: [10, 20, 15, 25, 30, 35],
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 1,
        fill: true
    }]

const config2 = {
    type: 'line',
    data: initialData,
    options: {
        responsive: true,
        animation: false,
        scales: {
            x: {
                title: {
                    display: true,
                    text: 'Time'
                }
            },
            y: {
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Value'
                }
            }
        }
    }
};

new Chart("BbmCRT", config2);
let chartInstance = Chart.getChart("BbmCRT");


function updateChart() {
    const newValue = Math.floor(Math.random() * 50) + 10;
    const lastLabel = Number(chartInstance.data.labels.slice(-1)[0].replace('s', '')) + 1;

    chartInstance.data.labels.push(`${lastLabel}s`);
    chartInstance.data.datasets[0].data.push(newValue);

    if (chartInstance.data.labels.length > 10) {
        chartInstance.data.labels.shift();
        chartInstance.data.datasets[0].data.shift();
    }

    chartInstance.update();
}

const newTimestamp = new Date(dataFromServer[dataFromServer.length - 1].timestamp);
const newLevel = dataFromServer[dataFromServer.length - 1].level;
const newNik = dataFromServer[dataFromServer.length - 1].nik;
    
console.log(newLevel);
console.log(newNik);

function updateChart() {
    // Simulasikan mendapatkan data baru dari dataFromServer
    const newTimestamp = new Date(dataFromServer[dataFromServer.length - 1].timestamp);
    const newLevel = dataFromServer[dataFromServer.length - 1].level;
    
    console.log(newLevel);
    
    // Perbarui label (timestamp) dan data level
    chartInstance.data.labels.push(newTimestamp.toLocaleTimeString()); // Gunakan format waktu lokal
    chartInstance.data.datasets[0].data.push(newLevel);

    // Jika jumlah data melebihi batas, hapus data lama
    if (chartInstance.data.labels.length > 10) {
        chartInstance.data.labels.shift(); // Hapus label pertama
        chartInstance.data.datasets[0].data.shift(); // Hapus data pertama
    }

    // Perbarui chart
    chartInstance.update();
}

let nikObject = {};

dataFromServer.forEach((record) => {

    nikObject[record.nik] = {
        level: record.level,
        timestamp: record.timestamp
    };
});

console.log(nikObject);

function updateChart() {
    // Ambil data terbaru dari dataFromServer
    const latestData = dataFromServer[dataFromServer.length - 1];
    const newTimestamp = new Date(latestData.timestamp).toLocaleTimeString(); // Format waktu lokal
    const newLevel = latestData.level;
    const newNik = latestData.nik;

    console.log(`Nik: ${newNik}, Level: ${newLevel}`);

    // Cek apakah dataset dengan nik tersebut sudah ada
    let dataset = chartInstance.data.datasets.find(ds => ds.label === newNik);

    // Jika dataset belum ada, tambahkan dataset baru
    if (!dataset) {
        const colorIndex = chartInstance.data.datasets.length % colors.length;
        const color = colors[colorIndex];
        chartInstance.data.datasets.push({
            label: newNik,
            fill: false,
            lineTension: 0,
            backgroundColor: color.backgroundColor,
            borderColor: color.borderColor,
            data: [] // Dataset baru dimulai dengan array kosong
        });
        dataset = chartInstance.data.datasets[chartInstance.data.datasets.length - 1];
    }

    // Tambahkan data baru ke dataset yang sesuai
    dataset.data.push({
        x: newTimestamp,
        y: newLevel
    });

    // Perbarui label pada sumbu x jika data bertambah
    if (!chartInstance.data.labels.includes(newTimestamp)) {
        chartInstance.data.labels.push(newTimestamp);
    }

    // Batasi jumlah data pada setiap dataset dan sumbu x menjadi 10
    const maxDataPoints = 10;

    // Pastikan data pada setiap dataset tidak lebih dari maxDataPoints
    if (chartInstance.data.labels.length > maxDataPoints) {
        chartInstance.data.labels.shift(); // Hapus label pertama
        chartInstance.data.datasets.forEach(ds => {
            ds.data.shift(); // Hapus data pertama dari setiap dataset
        });
    }

    // Perbarui chart
    chartInstance.update();
}

// Jalankan updateChart setiap detik untuk memastikan data diperbarui secara real-time
setInterval(updateChart, 1000);

let nikObject = {};

// Menyusun nikObject berdasarkan data dari server
dataFromServer.forEach((record) => {
    nikObject[record.nik] = {
        level: record.level,
        timestamp: record.timestamp
    };
});

function updateChart() {
    // Iterasi melalui semua NIK yang ada dalam nikObject
    for (let nik in nikObject) {
        if (nikObject.hasOwnProperty(nik)) {
            const { level, timestamp } = nikObject[nik];
            const newTimestamp = new Date(timestamp).toLocaleTimeString(); // Format waktu lokal
            const newLevel = level;

            //console.log(`Nik: ${nik}, Level: ${newLevel}`);

            // Cek apakah dataset dengan nik tersebut sudah ada
            let dataset = chartInstance.data.datasets.find(ds => ds.label === nik);

            // Jika dataset belum ada, tambahkan dataset baru
            if (!dataset) {
                const colorIndex = chartInstance.data.datasets.length % colors.length;
                const color = colors[colorIndex];
                chartInstance.data.datasets.push({
                    label: nik,
                    fill: false,
                    lineTension: 0,
                    backgroundColor: color.backgroundColor,
                    borderColor: color.borderColor,
                    data: [] // Dataset baru dimulai dengan array kosong
                });
                dataset = chartInstance.data.datasets[chartInstance.data.datasets.length - 1];
            }

            // Tambahkan data terbaru ke dataset yang sesuai
            dataset.data.push({
                x: newTimestamp,
                y: newLevel
            });

            // Perbarui label pada sumbu x jika data bertambah
            if (!chartInstance.data.labels.includes(newTimestamp)) {
                chartInstance.data.labels.push(newTimestamp);
            }
        }
    }

    // Batasi jumlah data pada setiap dataset dan sumbu x menjadi 10
    const maxDataPoints = 10;

    // Pastikan data pada setiap dataset tidak lebih dari maxDataPoints
    if (chartInstance.data.labels.length > maxDataPoints) {
        chartInstance.data.labels.shift(); // Hapus label pertama
        chartInstance.data.datasets.forEach(ds => {
            ds.data.shift(); // Hapus data pertama dari setiap dataset
        });
    }

    // Perbarui chart
    chartInstance.update();
}

// Jalankan updateChart setiap detik untuk memastikan data diperbarui secara real-time
setInterval(updateChart, 1000);
*/