$(document).ready(function () {
                $('#sqlForm').on('submit', function (e) {
                    e.preventDefault(); 
                    var sqlQuery = $('#sqlQuery').val();
                    var user_id = <?php echo $user->id; ?>;
                    
                    var responseElement = document.getElementById("response");
                    var tableId = null;
            
                    if (responseElement) {
                        var responseText = responseElement.innerHTML; // Contoh: "Table Changed [K01]"
                        //console.log(responseText);
                        
                        const start = responseText.indexOf('[') + 1;
                        const end = responseText.indexOf(']');
                        
                        if (start > 0 && end > start) {
                            tableId = responseText.substr(start, end - start);
                        }
                    }
                    
                    $.ajax({
                        
                        url: '/submit-sql', 
                        method: 'POST',
                        data: {
                            sqlQuery: sqlQuery,
                            user_id: user_id,
                            table_id: tableId,
                            _token: '{{ csrf_token() }}'
                        },
                        success: function  (response){
                            $('tbody').empty();
                            if (response.data && response.data.length > 0) {
                                $('tbody').html(`<tr><td colspan="4" id="response">${response.data}</td></tr>`);
                            } else {
                                $('tbody').html('<tr><td colspan="4">No data available</td></tr>');
                            }
                            
                            $('#responseMessage').html('<div class="alert alert-success">' + response.message + '</div>');
                            
                            /*
                            var responseElement = document.getElementById("response");
                            if (responseElement) {
                                var responseText = responseElement.innerHTML; 
                                const start = responseText.indexOf('[') + 1;
                                const end = responseText.indexOf(']');
                                
                                if (start > 0 && end > start) {
                                    var tableId = responseText.substr(start, end - start);
                                    console.log(tableId);
                                }
                            }*/
                        },
                        error: function (xhr) {
                            $('#responseMessage').html('<div class="alert alert-danger">Error: ' + xhr.responseText + '</div>');
                        }
                    });
                });
            });