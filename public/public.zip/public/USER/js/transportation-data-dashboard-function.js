var slider = document.getElementById("myRange");
var output = document.getElementById("demo");
output.innerHTML = slider.value;

slider.oninput = function() {
    output.innerHTML = this.value;
}

const tambahDataButton = document.getElementById('tambahDataButton');
const inputData = document.getElementById('inputData');
    
tambahDataButton.addEventListener('click', function(){
    inputData.innerHTML = '';

    var jumlahKendaraan = slider.value;

    for(var i = 1; i <= jumlahKendaraan; i++){
        var input = document.createElement('input');
        input.type = 'text';
        input.name = 'nik' + i;
        input.placeholder = 'NIK Kendaraan ' + i;
        input.style.display = 'block';
        input.style.margin = '10px 0';
        inputData.appendChild(input);
    }

    var simpanButton = document.createElement('button');
    simpanButton.id = 'simpanDataButton';
    simpanButton.style.borderRadius = '5px';
    simpanButton.innerHTML = 'Buat Tabel <br> Data Kendaraan';
    inputData.appendChild(simpanButton);
    simpanButton.addEventListener('click', function () {
        var dataKendaraan = [];
        var inputs = inputData.getElementsByTagName('input');
        for (var i = 0; i < inputs.length; i++) {
                dataKendaraan.push(inputs[i].value);
        }

        console.log('Data Kendaraan:', dataKendaraan);
        var nikInput = document.getElementById('nik');
        if (nikInput) {
            nikInput.value = JSON.stringify(dataKendaraan);
            document.getElementById('dataForm').submit();
        } else {
            console.error("Elemen dengan ID 'nik' tidak ditemukan.");
        }
    });

        if (inputData.style.display === 'none' || inputData.style.display === '') {
                inputData.style.display = 'block';
        } else {
                inputData.style.display = 'none';
        }
});