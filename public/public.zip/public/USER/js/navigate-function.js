function database() {
    document.getElementById('database').submit();
}

document.querySelectorAll('.li-link').forEach(function(element) {
    if (element.textContent.trim() === 'Database') {
        element.onclick = database;
    }
});

function monitoring() {
    document.getElementById('monitoring').submit();
}

document.querySelectorAll('.li-link').forEach(function(element) {
    if (element.textContent.trim() === 'Monitoring') {
        element.onclick = monitoring;
    }
});

function products() {
    document.getElementById('products').submit();
}

document.querySelectorAll('.li-link').forEach(function(element) {
    if (element.textContent.trim() === 'Products') {
        element.onclick = products;
    }
});

function maintenances() {
    document.getElementById('maintenances').submit();
}

document.querySelectorAll('.li-link').forEach(function(element) {
    if (element.textContent.trim() === 'Request Maintenance') {
        element.onclick = maintenances;
    }
});

function history() {
    document.getElementById('history').submit();
}

document.querySelectorAll('.li-link').forEach(function(element) {
    if (element.textContent.trim() === 'History') {
        element.onclick = history;
    }
});

function settings() {
    document.getElementById('setting').submit();
}

document.querySelectorAll('.li-link').forEach(function(element) {
    if (element.textContent.trim() === 'Settings') {
        element.onclick = settings;
    }
});
