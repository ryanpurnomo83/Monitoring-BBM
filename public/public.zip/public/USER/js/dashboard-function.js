var dataContainer = null;
var dataFromServer = null;

dataContainer = document.getElementById('data-container');
dataFromServer = JSON.parse(dataContainer.getAttribute('data-server-data'));

console.log(dataFromServer);

const xValues = dataFromServer.map(item => {
  
  function convertTo24HourFormat(hour, minute, second, period) {
      hour = parseInt(hour, 10);    // Mengubah string ke angka
      minute = parseInt(minute, 10);
      second = parseInt(second, 10);
    
      // Mengonversi jam PM ke format 24 jam
      if (period === 'PM' && hour !== 12) {
        hour += 12;
      } else if (period === 'AM' && hour === 12) {
        hour = 0; 
      }
    
      // Format dengan padding 2 digit (misalnya 01, 05, 10)
      return `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}:${second.toString().padStart(2, '0')}`;
  }    
    
  const date = item.timestamp;
  const dateParts = date.match(/(\w+) (\d+), (\d+)/);
  const timeParts = date.match(/(\d{1,2}:\d{2}:\d{2} [APM]+) UTC([+-]\d+)/);
  /*
  const day = date.toLocaleString('id-ID', { weekday: 'long' }); 
  const month = date.toLocaleString('id-ID', { month: 'short' }); 
  const dateNum = date.getDate();
  const year = date.getFullYear(); 
  //return `${day}, ${month} ${dateNum}, ${year}`;
  */
  
  if (dateParts && timeParts) {
    const month = dateParts[1];  // contoh: "November"
    const dateNum = dateParts[2]; // contoh: "11"
    const year = dateParts[3];    // contoh: "2024"
    
    const hour = timeParts[1].split(":")[0]; // Jam
    const minute = timeParts[1].split(":")[1]; // Menit
    const second = timeParts[1].split(":")[2]; // Detik
    const period = timeParts[2]; // AM/PM
    const utcOffset = timeParts[3]; // Zona waktu (misalnya "+7")

    
    const formattedTime = convertTo24HourFormat(hour, minute, second, period);
    
    //const day = '';${day}, 
    const formattedDate = `${year}-${monthToNumber(month)}-${dateNum}`;
    return { 
        formattedDate,
        formattedTime,
        original: `${month} ${dateNum}, ${year} ${hour}:${minute}:${second} ${period}` };
    //return `${month} ${dateNum}, ${year}`;
  }
  return '';
});

function monthToNumber(month) {
  const months = {
    January: '01', February: '02', March: '03', April: '04', May: '05', June: '06',
    July: '07', August: '08', September: '09', October: '10', November: '11', December: '12'
  };
  return months[month] || '01';
}

/*
xValues.sort((a, b) => {
  const dateA = new Date(a.formattedDate);
  const dateB = new Date(b.formattedDate);
  return dateA - dateB; 
  const timeA = a.formattedTime.split(":").join(""); // Hilangkan tanda ":" untuk membandingkan angka
  const timeB = b.formattedTime.split(":").join("");
  
  if (timeA !== timeB) {
    return timeA - timeB; // Urutkan berdasarkan waktu (time)
  }
  
  const dateA = new Date(a.formattedDate);
  const dateB = new Date(b.formattedDate);
  
  return dateA - dateB;
});*/

xValues.sort((a, b) => a.timestamp - b.timestamp);


const sortedXValues = xValues.map(item => item.original);
console.log(sortedXValues);

const groupedData = dataFromServer.reduce((acc, item) => {
  const nik = item.nik;
  if (!acc[nik]) {
    acc[nik] = [];
  }
  acc[nik].push(item);
  return acc;
}, {});

const colors = [
  { backgroundColor: "rgba(0,0,255,1.0)", borderColor: "rgba(0,0,255,0.6)" }, // Biru
  { backgroundColor: "rgba(255,165,0,1.0)", borderColor: "rgba(255,165,0,0.6)" }, // Oranye
  { backgroundColor: "rgba(0,128,0,1.0)", borderColor: "rgba(0,128,0,0.6)" }, // Hijau
  { backgroundColor: "rgba(255,0,0,1.0)", borderColor: "rgba(255,0,0,0.6)" } // Merah
];

/*
const datasets = Object.keys(groupedData).map((nik, index) => {
  const color = colors[index % colors.length];
  return {
    label: `${nik}`,
    fill: false,
    lineTension: 0,
    backgroundColor: color.backgroundColor,
    borderColor: color.borderColor,
    data: groupedData[nik].sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp)) // Urutkan data berdasarkan timestamp
                     .map(item => item.level),
    //data: groupedData[nik].map(item => item.level),
    xAxisID: 'x',
  };
});

if (datasets.length === 0) {
  datasets.push({
    label: "No Data",
    fill: false,
    lineTension: 0,
    backgroundColor: "rgba(211,211,211,1.0)",
    borderColor: "rgba(211,211,211,0.6)",
    data: Array(sortedXValues.length || 1).fill(0) // Isi 0 jika sortedXValues kosong
  });
  sortedXValues.push("No Data"); // Isi label default
}

new Chart("myChart", {
  type: "line",
  data: {
    labels: sortedXValues,
    datasets: datasets
  },
  options: {
    scales: {
      xAxes: [{
        type: 'time',
        time: {
          unit: 'day',
          tooltipFormat: 'MMM D, YYYY HH:mm',
          displayFormats: {
            day: 'MMM D',
            hour: 'HH:mm'
          }
        },
        ticks: {
          autoSkip: true,
          maxTicksLimit: 10
        }
      }],
      yAxes: [{
        ticks: {
          min: dataFromServer.length > 0 ? Math.max(...dataFromServer.map(item => item.level)) : 10,
          max: dataFromServer.length > 0 ? Math.min(...dataFromServer.map(item => item.level)) : 0,
        },
        scaleLabel: {
          display: true,
          labelString: 'Level'
        }
      }]
    },
    plugins: {
      zoom: {
        zoom: {
          wheel: {
            enabled: true,
          },
          pinch: {
            enabled: true
          },
          mode: 'xy',
        }
      }
    }
  }
});*/



function updateChart() {
    const newValue = Math.floor(Math.random() * 50) + 10; 
    const lastLabel = Number(chartInstance.data.labels.slice(-1)[0].replace('s', '')) + 1;

    chartInstance.data.labels.push(`${lastLabel}s`);
    chartInstance.data.datasets[0].data.push(newValue);

    if (chartInstance.data.labels.length > 10) {
        chartInstance.data.labels.shift();
        chartInstance.data.datasets[0].data.shift();
    }

    chartInstance.update();
}

setInterval(updateChart, 1000);
