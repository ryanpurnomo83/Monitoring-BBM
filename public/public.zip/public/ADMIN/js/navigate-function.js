function fileManager() {
    document.getElementById('file-manager').submit();
}

document.querySelectorAll('.li-link').forEach(function(element) {
    if (element.textContent.trim() === 'File Manager') {
        element.onclick = fileManager;
    }
});

// function monitoring() {
//     document.getElementById('monitoring').submit();
// }

// document.querySelectorAll('.li-link').forEach(function(element) {
//     if (element.textContent.trim() === 'Monitoring') {
//         element.onclick = monitoring;
//     }
// });

function products() {
    document.getElementById('products-manager').submit();
}

document.querySelectorAll('.li-link').forEach(function(element) {
    if (element.textContent.trim() === 'Products Manager') {
        element.onclick = products;
    }
});

function maintenances() {
    document.getElementById('admin-maintenances').submit();
}

document.querySelectorAll('.li-link').forEach(function(element) {
    if (element.textContent.trim() === 'Request Maintenance') {
        element.onclick = maintenances;
    }
});

function history() {
    document.getElementById('history-tracker').submit();
}

document.querySelectorAll('.li-link').forEach(function(element) {
    if (element.textContent.trim() === 'History Tracker') {
        element.onclick = history;
    }
});

function settings() {
    document.getElementById('admin-setting').submit();
}

document.querySelectorAll('.li-link').forEach(function(element) {
    if (element.textContent.trim() === 'Settings') {
        element.onclick = settings;
    }
});
