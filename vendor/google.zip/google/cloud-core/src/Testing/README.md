# Google Cloud Core Testing directory

This directory contains shared testing code that is used to implement unit,
snippet and system tests for both the Core library and other APIs. The code in
this directory is marked @experimental, and is **NOT** subject to the G.A. (1.0)
stability guarantee of the rest of the Google Cloud Core package.
